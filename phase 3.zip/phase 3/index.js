function enterButton() {

    const search = [eecs, javascript, css, html];
    if (enterButton = search[i]){
        alert("The word exists in the dictonary. Click to view the meaning!");
            window.open("./search.html");
    } 
  }